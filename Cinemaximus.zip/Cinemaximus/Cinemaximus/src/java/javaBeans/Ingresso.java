
package javaBeans;
public class Ingresso {
    public String filme;
    public String usuario; 
    public String email;
    public String horario;
    public String data; 

public void    deletar() {}

public boolean buscar() {return true;}

public void incluir() {
}
}

